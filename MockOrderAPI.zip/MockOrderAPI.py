import random
import uvicorn
import datetime
from typing import Union
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class Order(BaseModel):
   message: str

# Create orders dictionary
orders = {}

# Get on the root will return the entire dictionary
@app.get("/")
def read_root():
    return orders


@app.get("/orders/{order_id}")
def read_item(order_id: int, q: Union[str, None] = None):

    # For any order, check the dictionary. if it exists, return the current message
    order = orders.get(order_id)
    if order:
        return {"status" : order }
    else:
       messagenum = random.randint(1, 4)
       """ Generate random number between 1 and 4, \n
       1 means order has been delivered \n
       2 means order was shipped but not delivered \n
       3 means that the order has not yet been shipped \n
       4 means there is a problem with the order \n

       For each scenario caludate a semi-random date, then create the correspoding message for the scenario. \n
       Save this message to the dictionary by ORderID so taht we can use this the next tiem.
       """
       if messagenum == 1:
           mydate = datetime.date.today() - datetime.timedelta(days=random.randint(1,14))
           message = "Your order was delivered on " + mydate.strftime('%m/%d/%Y') + "."
           orders[order_id] = message
           return {"status" : message }
       elif messagenum == 2:
           mydate = datetime.date.today() - datetime.timedelta(days=random.randint(1,14))
           message =  "Your order was shipped on " + mydate.strftime('%m/%d/%Y') + "."
           orders[order_id] = message
           return {"status" : message }
       elif messagenum == 3:
           mydate = datetime.date.today() - datetime.timedelta(days=random.randint(1,30))
           message = "Your order will be shipped on or about " + mydate.strftime('%m/%d/%Y') + "."
           orders[order_id] = message
           return {"status" : message }
       else:
           message = "There was a problem with your order, please contact our support team."
           orders[order_id] = message
           return {"status" : message }


@app.put("/orders/{order_id}")
def update_item(order_id: int, order: Order):
    orders[order_id] = order
    return {"order_number": order_id, "message": order.message}

@app.delete("/orders/{order_id}")
def delete_item(order_id: int):
    # If the order id is in the dictionary, remove it so that the message can be regenerated, otherwise, return a failure message.
    if order_id in orders:
        del orders[order_id]
        return{"status" : "SUCCESS - Order removed from cache"}
    else:
        return{"status" : "FAILURE - Order not found in cache"}
        

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        log_level="debug",
        reload=True,
    )
